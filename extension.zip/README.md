# Study Cards Assistant

Une extension Firefox qui vous permet d'afficher des cartes avec des réponses sur n'importe quelle page web.

## Fonctionnalités

- Ajoutez facilement des cartes avec vos propres réponses, formules ou notes
- Importez et exportez vos cartes en formats texte, markdown ou JSON
- Organisez vos cartes par catégories (Mathématiques, Sciences, Histoire, etc.)
- Recherchez rapidement parmi vos cartes
- Affichage flottant et déplaçable sur n'importe quelle page web
- Raccourci clavier configurable (Ctrl+Q par défaut)
- Personnalisez l'apparence des cartes (opacité)

## Installation

### Installation temporaire

1. Téléchargez ou clonez ce dépôt
2. Ouvrez Firefox et tapez `about:debugging` dans la barre d'adresse
3. Cliquez sur "Ce Firefox" puis sur "Charger un module temporaire"
4. Naviguez jusqu'au répertoire de l'extension et sélectionnez le fichier `manifest.json`

### Installation permanente

1. Compressez le dossier de l'extension en fichier ZIP
2. Renommez l'extension du fichier de `.zip` à `.xpi`
3. Ouvrez Firefox et tapez `about:addons` dans la barre d'adresse
4. Cliquez sur l'icône d'engrenage (⚙️) et sélectionnez "Installer un module depuis un fichier"
5. Sélectionnez le fichier `.xpi` que vous avez créé

## Utilisation

1. Cliquez sur l'icône de l'extension dans la barre d'outils de Firefox
2. Ajoutez vos cartes dans l'onglet "Ajouter une carte"
3. Consultez vos cartes dans l'onglet "Mes cartes"
4. Les cartes apparaîtront automatiquement sur les pages web (configurable dans les paramètres)
5. Utilisez le raccourci clavier (Ctrl+Q par défaut) pour afficher/masquer les cartes
6. Déplacez les cartes en faisant glisser la barre supérieure

## Formats d'import/export

L'extension prend en charge trois formats pour importer et exporter vos cartes:

### Format texte
```
Titre de la carte
---
Contenu de la carte

Catégorie: Mathématiques
```

### Format Markdown
```markdown
# Titre de la carte

Contenu de la carte

*Catégorie: Mathématiques*
```

### Format JSON
```json
{
  "cards": [
    {
      "title": "Titre de la carte",
      "content": "Contenu de la carte",
      "category": "math"
    }
  ]
}
```

## Paramètres

Vous pouvez configurer les options suivantes dans l'onglet "Paramètres":

- **Affichage automatique**: Afficher automatiquement les cartes sur toutes les pages
- **Mode flottant**: Permettre le déplacement des cartes
- **Opacité des cartes**: Ajuster la transparence des cartes
- **Raccourci clavier**: Choisir le raccourci pour afficher/masquer les cartes

## Respect de la confidentialité

- Cette extension fonctionne entièrement localement et ne collecte aucune donnée
- Vos cartes et paramètres sont stockés uniquement dans votre navigateur
- Aucune information n'est envoyée à des serveurs externes

## Utilisation éducative

Cette extension est créée à des fins éducatives. Utilisez-la de manière responsable et en conformité avec les politiques de votre établissement d'enseignement. 