document.addEventListener('DOMContentLoaded', function() {
  // Éléments du DOM
  const tabs = document.querySelectorAll('.tab');
  const tabContents = document.querySelectorAll('.tab-content');
  const addCardBtn = document.getElementById('add-card-btn');
  const cardTitle = document.getElementById('card-title');
  const cardContent = document.getElementById('card-content');
  const cardCategory = document.getElementById('card-category');
  const cardsContainer = document.getElementById('cards-container');
  const searchCards = document.getElementById('search-cards');
  const addSuccess = document.getElementById('add-success');
  const settingsSuccess = document.getElementById('settings-success');
  const saveSettingsBtn = document.getElementById('save-settings');
  
  // Éléments pour l'import/export
  const importFile = document.getElementById('import-file');
  const fileName = document.getElementById('file-name');
  const importBtn = document.getElementById('import-btn');
  const importFormat = document.getElementById('import-format');
  const importCategory = document.getElementById('import-category');
  const importSuccess = document.getElementById('import-success');
  const exportBtn = document.getElementById('export-btn');
  const exportFormat = document.getElementById('export-format');
  const previewContainer = document.getElementById('preview-container');
  const filePreview = document.getElementById('file-preview');
  
  // Gestion des onglets
  tabs.forEach(tab => {
    tab.addEventListener('click', function() {
      // Supprimer la classe active de tous les onglets
      tabs.forEach(t => t.classList.remove('active'));
      tabContents.forEach(content => content.classList.remove('active'));
      
      // Ajouter la classe active à l'onglet cliqué
      this.classList.add('active');
      
      // Afficher le contenu correspondant
      const tabId = this.getAttribute('data-tab');
      document.getElementById(tabId).classList.add('active');
      
      // Charger les cartes si on va dans l'onglet de visualisation
      if (tabId === 'view-cards') {
        loadCards();
      }
    });
  });
  
  // ========== FONCTIONS POUR AJOUTER/VISUALISER LES CARTES ==========
  
  // Fonction pour ajouter une carte
  addCardBtn.addEventListener('click', function() {
    const title = cardTitle.value.trim();
    const content = cardContent.value.trim();
    const category = cardCategory.value;
    
    if (!title || !content) {
      alert('Veuillez remplir tous les champs obligatoires!');
      return;
    }
    
    addCard(title, content, category);
  });
  
  // Fonction réutilisable pour ajouter une carte
  function addCard(title, content, category) {
    // Vérifier que les champs requis sont remplis
    if (!title || !content) {
      return false;
    }
    
    // Formater le contenu avec plus d'espaces entre les options
    content = content.replace(/(\n|\r\n)(\n|\r\n)(\n|\r\n)/g, "\n\n\n\n\n");
    
    // Créer un nouvel objet carte
    const newCard = {
      id: Date.now(),
      title: title,
      content: content,
      category: category,
      dateAdded: new Date().toISOString()
    };
    
    // Ajouter la carte à la liste existante
    browser.storage.local.get('cards', function(data) {
      const cards = data.cards || [];
      cards.push(newCard);
      
      // Sauvegarder la liste mise à jour
      browser.storage.local.set({ cards: cards }, function() {
        // Actualiser l'affichage des cartes
        loadCards();
        
        // Afficher un message de succès
        const successMsg = document.getElementById('add-success');
        successMsg.style.display = 'block';
        
        // Cacher le message après quelques secondes
        setTimeout(function() {
          successMsg.style.display = 'none';
        }, 3000);
      });
    });
    
    return true;
  }
  
  // Fonction pour charger et afficher les cartes
  function loadCards(searchTerm = '') {
    browser.storage.local.get('cards', function(data) {
      const cards = data.cards || [];
      
      // Effacer le contenu actuel
      cardsContainer.innerHTML = '';
      
      if (cards.length === 0) {
        cardsContainer.innerHTML = '<div class="no-cards">Aucune carte ajoutée</div>';
        return;
      }
      
      // Filtrer si un terme de recherche est fourni
      let filteredCards = cards;
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        filteredCards = cards.filter(card => 
          card.title.toLowerCase().includes(term) || 
          card.content.toLowerCase().includes(term) ||
          (card.category && card.category.toLowerCase().includes(term))
        );
        
        if (filteredCards.length === 0) {
          cardsContainer.innerHTML = '<div class="no-cards">Aucun résultat trouvé</div>';
          return;
        }
      }
      
      // Afficher les cartes
      filteredCards.forEach(card => {
        const cardElement = document.createElement('div');
        cardElement.className = 'card';
        cardElement.innerHTML = `
          <div class="card-title">${card.title}</div>
          <div class="card-content">${card.content}</div>
          <button class="delete-btn" data-id="${card.id}">×</button>
        `;
        
        // Ajouter une indication de catégorie si disponible
        if (card.category) {
          cardElement.style.borderLeft = '3px solid ' + getCategoryColor(card.category);
        }
        
        cardsContainer.appendChild(cardElement);
      });
      
      // Ajouter les écouteurs pour les boutons de suppression
      document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', function() {
          const cardId = parseInt(this.getAttribute('data-id'));
          deleteCard(cardId);
        });
      });
    });
  }
  
  // Fonction pour obtenir une couleur basée sur la catégorie
  function getCategoryColor(category) {
    const colors = {
      'math': '#4caf50',
      'science': '#2196f3',
      'history': '#ff9800',
      'language': '#9c27b0',
      'other': '#607d8b'
    };
    
    return colors[category] || '#607d8b';
  }
  
  // Fonction pour supprimer une carte
  function deleteCard(cardId) {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette carte ?')) {
      browser.storage.local.get('cards', function(data) {
        const cards = data.cards || [];
        const updatedCards = cards.filter(card => card.id !== cardId);
        
        browser.storage.local.set({ cards: updatedCards }, function() {
          loadCards(searchCards.value.trim());
        });
      });
    }
  }
  
  // Gérer la recherche
  searchCards.addEventListener('input', function() {
    loadCards(this.value.trim());
  });
  
  // ========== FONCTIONS POUR L'IMPORT/EXPORT ==========
  
  // Gestion de la sélection d'un fichier
  importFile.addEventListener('change', function(e) {
    if (e.target.files.length > 0) {
      const file = e.target.files[0];
      fileName.textContent = file.name;
      importBtn.disabled = false;
      
      // Lire le fichier pour aperçu
      const reader = new FileReader();
      reader.onload = function(event) {
        const content = event.target.result;
        
        // Afficher un aperçu du contenu
        previewContainer.style.display = 'block';
        
        // Limiter l'aperçu à 500 caractères
        if (content.length > 500) {
          filePreview.textContent = content.substring(0, 500) + '...';
        } else {
          filePreview.textContent = content;
        }
      };
      reader.readAsText(file);
    } else {
      fileName.textContent = 'Aucun fichier sélectionné';
      importBtn.disabled = true;
      previewContainer.style.display = 'none';
    }
  });
  
  // Fonction pour importer les cartes
  importBtn.addEventListener('click', function() {
    if (importFile.files.length === 0) {
      alert('Veuillez sélectionner un fichier à importer.');
      return;
    }
    
    const file = importFile.files[0];
    const reader = new FileReader();
    
    reader.onload = function(event) {
      const content = event.target.result;
      const format = importFormat.value;
      const defaultCategory = importCategory.value;
      
      let parsedCards = [];
      
      try {
        switch (format) {
          case 'text':
            parsedCards = parseTextFormat(content, defaultCategory);
            break;
          case 'markdown':
            parsedCards = parseMarkdownFormat(content, defaultCategory);
            break;
          case 'json':
            parsedCards = parseJSONFormat(content, defaultCategory);
            break;
        }
        
        if (parsedCards.length === 0) {
          alert('Aucune carte valide trouvée dans le fichier.');
          return;
        }
        
        // Récupérer les cartes existantes et ajouter les nouvelles
        browser.storage.local.get('cards', function(data) {
          const existingCards = data.cards || [];
          const newCards = [...existingCards, ...parsedCards];
          
          browser.storage.local.set({ cards: newCards }, function() {
            // Réinitialiser le formulaire d'import
            importFile.value = '';
            fileName.textContent = 'Aucun fichier sélectionné';
            importBtn.disabled = true;
            previewContainer.style.display = 'none';
            
            // Afficher le message de succès
            importSuccess.style.display = 'block';
            importSuccess.textContent = `${parsedCards.length} cartes importées avec succès!`;
            setTimeout(() => {
              importSuccess.style.display = 'none';
            }, 3000);
          });
        });
        
      } catch (error) {
        alert('Erreur lors de l\'analyse du fichier: ' + error.message);
      }
    };
    
    reader.readAsText(file);
  });
  
  // Fonction pour analyser le format texte
  function parseTextFormat(content, defaultCategory) {
    const cards = [];
    const blocks = content.split(/\n{2,}/); // Séparer par lignes vides
    
    blocks.forEach(block => {
      const parts = block.split(/\n---\n|\r\n---\r\n/);
      if (parts.length >= 2) {
        const title = parts[0].trim();
        const content = parts[1].trim();
        
        if (title && content) {
          cards.push({
            id: Date.now() + Math.floor(Math.random() * 1000) + cards.length,
            title: title,
            content: content,
            category: defaultCategory,
            dateAdded: new Date().toISOString()
          });
        }
      }
    });
    
    return cards;
  }
  
  // Fonction pour analyser le format markdown
  function parseMarkdownFormat(content, defaultCategory) {
    const cards = [];
    const blocks = content.split(/(?=^# )/m); // Séparer par titres de niveau 1
    
    blocks.forEach(block => {
      if (block.trim()) {
        const lines = block.trim().split('\n');
        
        // Si le bloc commence par un titre de niveau 1
        if (lines[0].startsWith('# ')) {
          const title = lines[0].substring(2).trim();
          const content = lines.slice(1).join('\n').trim();
          
          if (title && content) {
            cards.push({
              id: Date.now() + Math.floor(Math.random() * 1000) + cards.length,
              title: title,
              content: content,
              category: defaultCategory,
              dateAdded: new Date().toISOString()
            });
          }
        }
      }
    });
    
    return cards;
  }
  
  // Fonction pour analyser le format JSON
  function parseJSONFormat(content, defaultCategory) {
    try {
      const data = JSON.parse(content);
      const cards = [];
      
      // Si c'est un tableau
      if (Array.isArray(data)) {
        data.forEach(item => {
          if (item.title && item.content) {
            cards.push({
              id: Date.now() + Math.floor(Math.random() * 1000) + cards.length,
              title: item.title,
              content: item.content,
              category: item.category || defaultCategory,
              dateAdded: new Date().toISOString()
            });
          }
        });
      } 
      // Si c'est un objet avec une propriété cards
      else if (data.cards && Array.isArray(data.cards)) {
        data.cards.forEach(item => {
          if (item.title && item.content) {
            cards.push({
              id: Date.now() + Math.floor(Math.random() * 1000) + cards.length,
              title: item.title,
              content: item.content,
              category: item.category || defaultCategory,
              dateAdded: new Date().toISOString()
            });
          }
        });
      }
      
      return cards;
    } catch (error) {
      throw new Error('Format JSON invalide');
    }
  }
  
  // Fonction pour exporter les cartes
  exportBtn.addEventListener('click', function() {
    browser.storage.local.get('cards', function(data) {
      const cards = data.cards || [];
      
      if (cards.length === 0) {
        alert('Aucune carte à exporter.');
        return;
      }
      
      const format = exportFormat.value;
      let content = '';
      let filename = '';
      let mimeType = '';
      
      switch (format) {
        case 'text':
          content = exportAsText(cards);
          filename = 'mes_cartes.txt';
          mimeType = 'text/plain';
          break;
        case 'markdown':
          content = exportAsMarkdown(cards);
          filename = 'mes_cartes.md';
          mimeType = 'text/markdown';
          break;
        case 'json':
          content = exportAsJSON(cards);
          filename = 'mes_cartes.json';
          mimeType = 'application/json';
          break;
      }
      
      // Créer un blob et déclencher le téléchargement
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      
      // Nettoyer
      setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }, 100);
    });
  });
  
  // Fonction pour exporter au format texte
  function exportAsText(cards) {
    return cards.map(card => {
      let text = card.title + '\n---\n' + card.content;
      if (card.category) {
        text += '\n\nCatégorie: ' + getCategoryLabel(card.category);
      }
      return text;
    }).join('\n\n\n');
  }
  
  // Fonction pour exporter au format markdown
  function exportAsMarkdown(cards) {
    return cards.map(card => {
      let md = '# ' + card.title + '\n\n' + card.content;
      if (card.category) {
        md += '\n\n*Catégorie: ' + getCategoryLabel(card.category) + '*';
      }
      return md;
    }).join('\n\n\n');
  }
  
  // Fonction pour exporter au format JSON
  function exportAsJSON(cards) {
    const exportData = cards.map(card => ({
      title: card.title,
      content: card.content,
      category: card.category,
      dateAdded: card.dateAdded
    }));
    
    return JSON.stringify({ cards: exportData }, null, 2);
  }
  
  // Obtenir le libellé d'une catégorie
  function getCategoryLabel(category) {
    const labels = {
      'math': 'Mathématiques',
      'science': 'Sciences',
      'history': 'Histoire',
      'language': 'Langues',
      'other': 'Autre'
    };
    
    return labels[category] || 'Autre';
  }
  
  // ========== FONCTIONS POUR LES PARAMÈTRES ==========
  
  // Enregistrer les paramètres
  saveSettingsBtn.addEventListener('click', function() {
    const settings = {
      autoShow: document.getElementById('auto-show').checked,
      floatingMode: document.getElementById('floating-mode').checked,
      opacity: document.getElementById('card-opacity').value,
      shortcut: document.getElementById('shortcut').value
    };
    
    browser.storage.local.set({ settings: settings }, function() {
      // Envoyer les nouveaux paramètres au script de contenu
      browser.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        browser.tabs.sendMessage(tabs[0].id, { action: 'updateSettings', settings: settings });
      });
      
      // Afficher le message de succès
      settingsSuccess.style.display = 'block';
      setTimeout(() => {
        settingsSuccess.style.display = 'none';
      }, 3000);
    });
  });
  
  // Charger les paramètres existants
  browser.storage.local.get('settings', function(data) {
    if (data.settings) {
      document.getElementById('auto-show').checked = data.settings.autoShow !== false;
      document.getElementById('floating-mode').checked = data.settings.floatingMode !== false;
      document.getElementById('card-opacity').value = data.settings.opacity || 0.9;
      
      if (data.settings.shortcut) {
        document.getElementById('shortcut').value = data.settings.shortcut;
      }
    }
  });
}); 